# MIEIC_18_19_CGRA
Exercises for the TP classes of CGRA
