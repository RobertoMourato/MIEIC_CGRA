function scaling(vector){
    return [
        vector[0], 0, 0, 0,
        0, vector[1], 0, 0,
        0, 0, vector[2], 0,
        0, 0, 0, 1
    ]
}